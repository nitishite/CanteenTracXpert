package com.example.christcanteenonlineorderingsystem.Adapters;

import com.example.christcanteenonlineorderingsystem.model.MenuItem;

public interface NavigateInterface {
    void onNavigate(MenuItem itemName);
}
