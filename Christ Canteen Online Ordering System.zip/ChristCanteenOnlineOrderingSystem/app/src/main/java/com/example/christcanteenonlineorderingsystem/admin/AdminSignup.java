package com.example.christcanteenonlineorderingsystem.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.christcanteenonlineorderingsystem.R;

public class AdminSignup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_signup);
    }
}